const animals = [
  { name: "cat", sound: "meow" },
  { name: "dog", sound: "woof" }
];
