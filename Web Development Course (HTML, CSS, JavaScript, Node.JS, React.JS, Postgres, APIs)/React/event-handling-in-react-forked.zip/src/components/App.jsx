import React from "react";

function App() {
  const [text, setText] = React.useState("Hello");
  const [buttonOver, setButtonOver] = React.useState(false);

  function updateText() {
    setText("Test");
  }

  function mouseOver() {
    setButtonOver(true);
  }

  function mouseOut() {
    setButtonOver(false);
  }

  return (
    <div className="container">
      <h1>{text}</h1>
      <input type="text" placeholder="What's your name?" />
      <button
        onClick={updateText}
        onMouseOver={mouseOver}
        onMouseOut={mouseOut}
        style={{ backgroundColor: buttonOver ? "black" : "white" }}
      >
        Submit
      </button>
    </div>
  );
}

export default App;
