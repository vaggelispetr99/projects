import React from "react";
import ReactDOM from "react-dom";

const picsumImg = "https://picsum.photos/100";

ReactDOM.render(
  <div>
    <h1 className="heading" contentEditable="true" spellCheck="false">
      My Favourite Foods
    </h1>
    <ul>
      <li>Bacon</li>
      <li>Jamon</li>
      <li>Noodles</li>
    </ul>
    <div>
      <img
        className="images"
        alt="noodles"
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Mama_instant_noodle_block.jpg/1200px-Mama_instant_noodle_block.jpg"
      />
      <img
        className="images"
        alt="noodles"
        src="https://www.chilipeppermadness.com/wp-content/uploads/2023/06/Gochujang-Noodles-Recipe1.jpg"
      />
      <img className="images" alt="random" src={picsumImg + "?grayscale"} />
    </div>
  </div>,
  document.getElementById("root")
);
