import React from "react";

function App() {
  const [currentTime, updateTime] = React.useState(
    new Date().toLocaleTimeString("el-GR", { hour12: false })
  );
  function newTime() {
    updateTime(new Date().toLocaleTimeString("el-GR", { hour12: false }));
  }
  setInterval(newTime, 1000);
  return (
    <div className="container">
      <h1>{currentTime}</h1>
      <button onClick={newTime}>Get Time</button>
    </div>
  );
}

export default App;
