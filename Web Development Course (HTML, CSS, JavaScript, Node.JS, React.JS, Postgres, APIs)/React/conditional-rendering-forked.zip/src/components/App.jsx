import React from "react";
import Login from "./Login";

var isLoggedIn = false;
var hour = new Date(2024, 8, 7, 14).getHours();

function RenderLogin() {
  if (isLoggedIn) {
    return <Login />;
  } else {
    return <h1>Hello</h1>;
  }
}

function App() {
  return (
    <div className="container">
      {isLoggedIn ? <h1>Hello</h1> : <Login />}
      {hour > 13 && <h1>Why are you still working?</h1>} //alternatives
      {hour > 13 ? <h2>Copyright Vaggospetr</h2> : null} //alternatives
    </div>
  );
}

//<script>alert("Email already exists! Try logging in!"); window.location.href = "/register"; </script>
export default App;
