// var React = require("react");
// var ReactDom = require("react-dom");

import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1>Hello World</h1>
    <p>New element</p>
  </div>,
  document.getElementById("root")
);
