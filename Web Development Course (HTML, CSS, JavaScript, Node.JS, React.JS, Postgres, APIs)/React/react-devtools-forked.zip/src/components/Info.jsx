import React from "react";

function Info(props) {
  return <p className="info">{props.info}</p>;
}

export default Info;
