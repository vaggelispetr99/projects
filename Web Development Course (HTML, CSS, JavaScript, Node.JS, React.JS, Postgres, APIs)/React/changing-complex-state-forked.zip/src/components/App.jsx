import React from "react";

function App() {
  const [fullName, setFullName] = React.useState({
    fname: "",
    lname: "",
  });

  function setFullNameFunc(event) {
    const { name, value } = event.target;
    setFullName((prevObj) => {
      if (name === "fName") {
        return {
          fname: value,
          lname: prevObj.lname,
        };
      } else {
        return {
          fname: prevObj.fname,
          lname: value,
        };
      }
    });
  }

  return (
    <div className="container">
      <h1>
        Hello {fullName.fname} {fullName.lname}
      </h1>
      <form>
        <input
          onChange={setFullNameFunc}
          name="fName"
          placeholder="First Name"
          value={fullName.fname}
        />
        <input
          onChange={setFullNameFunc}
          name="lName"
          placeholder="Last Name"
          value={fullName.lname}
        />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
