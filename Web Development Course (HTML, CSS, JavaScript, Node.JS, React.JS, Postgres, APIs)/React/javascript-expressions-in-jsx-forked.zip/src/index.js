import React from "react";
import ReactDOM from "react-dom";

var fname = "Vaggos";
var lname = "Petr";
// var number = 6;
ReactDOM.render(
  <div>
    <h1>
      Hello I am {fname} {lname}!
    </h1>
    <p>My lucky number is {Math.floor(Math.random() * 100)}</p>
  </div>,
  document.getElementById("root")
);
